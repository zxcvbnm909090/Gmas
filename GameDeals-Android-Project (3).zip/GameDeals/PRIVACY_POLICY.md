# Privacy Policy – Game Deals – Free Games

Last updated: November 2026

Game Deals – Free Games ("the app") shows free games and discounted games from third-party services.

## Data we collect
The app does not require an account and does not collect your name, email, or phone number.

- **Favorites and settings** are stored only on your device.
- **Notifications:** the app checks for new offers in the background and shows notifications if you allow them. You can turn them off in the app settings or in your phone settings.

## Third-party services
The app contacts these services to load game data, and they receive your IP address as part of normal internet requests:
- GamerPower (gamerpower.com) – free game giveaways
- CheapShark (cheapshark.com) – game deals
- RAWG (rawg.io) – game details and ratings

When you open a store link, you leave the app and the store's own privacy policy applies.

## Advertising
The app uses Google AdMob and Unity Ads to show ads. These services may collect device identifiers (such as the advertising ID) and usage data to show and measure ads. See Google's policy: https://policies.google.com/privacy and Unity's policy: https://unity.com/legal/privacy-policy

## Children
The app is not directed to children under 13.

## Changes
We may update this policy. The latest version will always be available at the link shown on the store page.

## Contact
Fhhbuhh@gmail.com

# Game Deals – Free Games (Android)

Kotlin + Jetpack Compose app. Real data from GamerPower (free games), CheapShark (deals) and RAWG (details).

## Get the APK with GitHub Actions (no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Optional: Settings → Secrets and variables → Actions → New secret `RAWG_API_KEY` (free key from rawg.io/apidocs).
3. Open the Actions tab → "Build APK" → Run workflow (it also runs on every push).
4. When it finishes (about 5 minutes), open the run and download the `GameDeals-apk` artifact. Unzip it and install `app-release.apk` on your phone.

## Before publishing
- Replace the AdMob TEST ids in `AndroidManifest.xml` and `Store.kt` (`Config`).
- Add affiliate tracking in `Config.AFFILIATE_QUERY`.
- Sign with your own keystore for Google Play.

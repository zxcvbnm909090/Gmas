plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val ksFile = (project.findProperty("KEYSTORE_FILE") as String?)?.let { file(it) }
val ksPass = project.findProperty("KEYSTORE_PASSWORD") as String?
val hasKeystore = ksFile != null && ksFile.exists() && !ksPass.isNullOrEmpty()

android {
    namespace = "com.gamedeals.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gamedeals.app"
        minSdk = 26
        targetSdk = 35
        versionCode = ((project.findProperty("VERSION_CODE") as String?)?.toIntOrNull() ?: 1)
        versionName = "1.0"
        val rawg = (project.findProperty("RAWG_API_KEY") as String?) ?: ""
        buildConfigField("String", "RAWG_KEY", "\"$rawg\"")
    }

    signingConfigs {
        if (hasKeystore) {
            create("release") {
                storeFile = ksFile
                storePassword = ksPass
                keyAlias = "gamedeals"
                keyPassword = ksPass
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Uses your own keystore when available, otherwise the debug key (install-only).
            signingConfig = if (hasKeystore) signingConfigs.getByName("release")
            else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")

    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.google.android.gms:play-services-ads:23.5.0")
    implementation("com.unity3d.ads:unity-ads:4.12.5")
}

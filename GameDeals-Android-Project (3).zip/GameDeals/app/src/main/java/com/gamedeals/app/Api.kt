package com.gamedeals.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

/** Real data sources: GamerPower (free games), CheapShark (deals), RAWG (details). */
object Api {
    private const val TTL = 15 * 60 * 1000L
    private lateinit var cacheDir: File

    fun init(ctx: Context) {
        cacheDir = File(ctx.cacheDir, "api").apply { mkdirs() }
    }

    /** Network first (unless cached copy is fresh); falls back to stale cache when offline. */
    private fun fetch(url: String, force: Boolean): String {
        val f = File(cacheDir, "c" + url.hashCode().toString())
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < TTL) {
            return f.readText()
        }
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "GameDeals/1.0")
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val t = c.inputStream.bufferedReader().use { it.readText() }
            f.writeText(t)
            t
        } catch (e: Exception) {
            if (f.exists()) f.readText() else throw e
        }
    }

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")

    private fun parseDate(s: String): Long? {
        if (s.isBlank() || s.equals("N/A", true)) return null
        return try {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                .apply { timeZone = TimeZone.getTimeZone("UTC") }
                .parse(s)?.time
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- GamerPower: free games ----------------
    suspend fun free(platform: String?, force: Boolean = false): List<Game> = withContext(Dispatchers.IO) {
        val url = if (platform == null)
            "https://www.gamerpower.com/api/giveaways?type=game&sort-by=popularity"
        else
            "https://www.gamerpower.com/api/filter?platform=$platform&type=game&sort-by=popularity"
        val t = fetch(url, force).trim()
        if (!t.startsWith("[")) emptyList() else parseFree(JSONArray(t))
    }

    private fun parseFree(a: JSONArray): List<Game> {
        val out = ArrayList<Game>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val status = o.str("status")
            if (status.isNotEmpty() && !status.equals("Active", true)) continue
            val worth = o.str("worth").replace("$", "").trim().toDoubleOrNull()
            val instr = o.str("instructions")
            val desc = o.str("description") + if (instr.isNotEmpty()) "\n\n$instr" else ""
            out.add(
                Game(
                    id = "free_" + o.optInt("id"),
                    kind = Kind.FREE,
                    title = o.str("title").replace(Regex("\\s*Giveaway$"), ""),
                    image = o.str("image").ifEmpty { o.str("thumbnail") },
                    description = desc,
                    platforms = o.str("platforms"),
                    originalPrice = worth,
                    currentPrice = 0.0,
                    discountPct = 100,
                    endDate = parseDate(o.str("end_date")),
                    rating = null,
                    storeName = o.str("platforms").split(",").firstOrNull()?.trim() ?: "",
                    url = o.str("open_giveaway_url").ifEmpty { o.str("gamerpower_url") }
                )
            )
        }
        return out
    }

    // ---------------- CheapShark: deals ----------------
    private fun storeNames(): Map<String, String> = try {
        val a = JSONArray(fetch("https://www.cheapshark.com/api/1.0/stores", false))
        (0 until a.length()).associate {
            val o = a.getJSONObject(it)
            o.str("storeID") to o.str("storeName")
        }
    } catch (e: Exception) {
        emptyMap()
    }

    suspend fun deals(storeId: String?, force: Boolean = false, title: String? = null): List<Game> = withContext(Dispatchers.IO) {
        val names = storeNames()
        var url = "https://www.cheapshark.com/api/1.0/deals?onSale=1&sortBy=Savings&desc=1&lowerPrice=0.01&pageSize=60"
        if (storeId != null) url += "&storeID=$storeId"
        if (!title.isNullOrBlank()) url += "&title=" + URLEncoder.encode(title, "UTF-8")
        val a = JSONArray(fetch(url, force))
        val out = ArrayList<Game>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val normal = o.str("normalPrice").toDoubleOrNull() ?: continue
            val sale = o.str("salePrice").toDoubleOrNull() ?: continue
            val pct = (o.str("savings").toDoubleOrNull() ?: 0.0).roundToInt()
            val steamId = o.str("steamAppID")
            val img = if (steamId.isNotEmpty() && steamId != "0")
                "https://cdn.cloudflare.steamstatic.com/steam/apps/$steamId/header.jpg"
            else o.str("thumb")
            val rating = o.str("steamRatingPercent").toIntOrNull()?.takeIf { it > 0 }
                ?: o.str("metacriticScore").toIntOrNull()?.takeIf { it > 0 }
            val dealId = o.str("dealID")
            out.add(
                Game(
                    id = "deal_$dealId",
                    kind = Kind.DEAL,
                    title = o.str("title"),
                    image = img,
                    description = "",
                    platforms = "PC",
                    originalPrice = normal,
                    currentPrice = sale,
                    discountPct = pct,
                    endDate = null,
                    rating = rating,
                    storeName = names[o.str("storeID")] ?: "Store",
                    url = "https://www.cheapshark.com/redirect?dealID=" + URLEncoder.encode(dealId, "UTF-8")
                )
            )
        }
        out.sortedByDescending { it.discountPct }
    }

    /** Cheapest current price for a title across stores (used for wishlist price-drop alerts). */
    suspend fun cheapest(title: String): Pair<Double, String>? = withContext(Dispatchers.IO) {
        val q = URLEncoder.encode(title, "UTF-8")
        val a = JSONArray(fetch("https://www.cheapshark.com/api/1.0/games?title=$q&exact=1", true))
        val o = a.optJSONObject(0) ?: return@withContext null
        val p = o.str("cheapest").toDoubleOrNull() ?: return@withContext null
        Pair(p, "https://www.cheapshark.com/redirect?dealID=" + URLEncoder.encode(o.str("cheapestDealID"), "UTF-8"))
    }

    // ---------------- RAWG: details ----------------
    suspend fun rawg(title: String): Rawg? = withContext(Dispatchers.IO) {
        val key = BuildConfig.RAWG_KEY
        if (key.isBlank()) return@withContext null
        try {
            val q = URLEncoder.encode(title, "UTF-8")
            val s = JSONObject(fetch("https://api.rawg.io/api/games?key=$key&search=$q&search_precise=true&page_size=1", false))
            val r = s.optJSONArray("results")?.optJSONObject(0) ?: return@withContext null
            val d = JSONObject(fetch("https://api.rawg.io/api/games/${r.optInt("id")}?key=$key", false))
            Rawg(
                rating = r.optDouble("rating", 0.0).takeIf { it > 0 },
                image = r.str("background_image").ifEmpty { null },
                description = d.str("description_raw").ifEmpty { null }
            )
        } catch (e: Exception) {
            null
        }
    }
}

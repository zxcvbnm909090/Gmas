package com.gamedeals.app

import org.json.JSONObject

enum class Kind { FREE, DEAL }

data class Game(
    val id: String,
    val kind: Kind,
    val title: String,
    val image: String,
    val description: String,
    val platforms: String,
    val originalPrice: Double?,
    val currentPrice: Double?,
    val discountPct: Int,
    val endDate: Long?,
    val rating: Int?,
    val storeName: String,
    val url: String
)

data class Rawg(val rating: Double?, val image: String?, val description: String?)

data class UiState(
    val loading: Boolean = false,
    val error: String? = null,
    val items: List<Game> = emptyList()
)

fun Game.toJson(): JSONObject = JSONObject().apply {
    put("id", id)
    put("kind", kind.name)
    put("title", title)
    put("image", image)
    put("description", description)
    put("platforms", platforms)
    originalPrice?.let { put("op", it) }
    currentPrice?.let { put("cp", it) }
    put("pct", discountPct)
    endDate?.let { put("end", it) }
    rating?.let { put("rating", it) }
    put("store", storeName)
    put("url", url)
}

fun JSONObject.toGame(): Game = Game(
    id = getString("id"),
    kind = Kind.valueOf(getString("kind")),
    title = getString("title"),
    image = optString("image"),
    description = optString("description"),
    platforms = optString("platforms"),
    originalPrice = if (has("op")) getDouble("op") else null,
    currentPrice = if (has("cp")) getDouble("cp") else null,
    discountPct = optInt("pct"),
    endDate = if (has("end")) getLong("end") else null,
    rating = if (has("rating")) getInt("rating") else null,
    storeName = optString("store"),
    url = optString("url")
)

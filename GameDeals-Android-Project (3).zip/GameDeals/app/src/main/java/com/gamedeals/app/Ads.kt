package com.gamedeals.app

import android.app.Activity
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions

/** Runs AdMob and Unity Ads side by side. */
object Ads {
    var unityReady by mutableStateOf(false)
        private set

    var admobBannerStatus by mutableStateOf("not requested")
    var admobInterstitialStatus by mutableStateOf("not requested")
    var unityStatus by mutableStateOf("initializing")

    fun bannerId() = if (Store.useTestAds) Config.TEST_BANNER_ID else Config.ADMOB_BANNER_ID
    fun interstitialId() = if (Store.useTestAds) Config.TEST_INTERSTITIAL_ID else Config.ADMOB_INTERSTITIAL_ID
    fun rewardedId() = if (Store.useTestAds) Config.TEST_REWARDED_ID else Config.ADMOB_REWARDED_ID

    private var started = false
    private var admobInterstitial: InterstitialAd? = null
    private var unityInterstitialReady = false
    private var count = 0
    private var lastShown = 0L
    private var unityNext = false

    fun init(act: Activity) {
        if (started) return
        started = true
        MobileAds.initialize(act)
        loadAdMobInterstitial(act.applicationContext)
        UnityAds.initialize(
            act.applicationContext, Config.UNITY_GAME_ID, Config.UNITY_TEST_MODE,
            object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() {
                    unityReady = true
                    unityStatus = "ready"
                    loadUnityInterstitial()
                }

                override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError?, message: String?) {
                    unityReady = false
                    unityStatus = "init failed: $error $message"
                }
            }
        )
    }

    fun adsHidden(): Boolean = System.currentTimeMillis() < Store.adsFreeUntil

    // ---------------- Interstitial (every 3rd detail close, at least 3 min apart) ----------------
    fun onDetailClosed(act: Activity) {
        if (adsHidden()) return
        count++
        val now = System.currentTimeMillis()
        if (count % 3 != 0 || now - lastShown < 3 * 60_000L) return
        val unityFirst = unityNext
        val shown = if (unityFirst) showUnityInterstitial(act) || showAdMobInterstitial(act)
        else showAdMobInterstitial(act) || showUnityInterstitial(act)
        if (shown) {
            lastShown = now
            unityNext = !unityFirst
        }
    }

    private fun loadAdMobInterstitial(ctx: Context) {
        InterstitialAd.load(ctx, interstitialId(), AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    admobInterstitial = ad
                    admobInterstitialStatus = "loaded"
                }

                override fun onAdFailedToLoad(e: LoadAdError) {
                    admobInterstitial = null
                    admobInterstitialStatus = "failed ${e.code}: ${e.message}"
                }
            })
    }

    private fun showAdMobInterstitial(act: Activity): Boolean {
        val ad = admobInterstitial ?: return false
        admobInterstitial = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                loadAdMobInterstitial(act.applicationContext)
            }

            override fun onAdFailedToShowFullScreenContent(e: AdError) {
                loadAdMobInterstitial(act.applicationContext)
            }
        }
        ad.show(act)
        return true
    }

    private fun loadUnityInterstitial() {
        if (!unityReady) return
        UnityAds.load(Config.UNITY_INTERSTITIAL, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) {
                unityInterstitialReady = true
            }

            override fun onUnityAdsFailedToLoad(placementId: String?, error: UnityAds.UnityAdsLoadError?, message: String?) {
                unityInterstitialReady = false
            }
        })
    }

    private fun showUnityInterstitial(act: Activity): Boolean {
        if (!unityReady || !unityInterstitialReady) return false
        unityInterstitialReady = false
        UnityAds.show(act, Config.UNITY_INTERSTITIAL, UnityAdsShowOptions(), object : IUnityAdsShowListener {
            override fun onUnityAdsShowFailure(placementId: String?, error: UnityAds.UnityAdsShowError?, message: String?) {
                loadUnityInterstitial()
            }

            override fun onUnityAdsShowStart(placementId: String?) {}
            override fun onUnityAdsShowClick(placementId: String?) {}
            override fun onUnityAdsShowComplete(placementId: String?, state: UnityAds.UnityAdsShowCompletionState?) {
                loadUnityInterstitial()
            }
        })
        return true
    }

    // ---------------- Rewarded ----------------
    fun showRewardedAdMob(act: Activity, onReward: () -> Unit, onFail: () -> Unit) {
        RewardedAd.load(act, rewardedId(), AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                ad.show(act) { onReward() }
            }

            override fun onAdFailedToLoad(e: LoadAdError) {
                onFail()
            }
        })
    }

    fun showRewardedUnity(act: Activity, onReward: () -> Unit, onFail: () -> Unit) {
        if (!unityReady) {
            onFail()
            return
        }
        UnityAds.load(Config.UNITY_REWARDED, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) {
                UnityAds.show(act, Config.UNITY_REWARDED, UnityAdsShowOptions(), object : IUnityAdsShowListener {
                    override fun onUnityAdsShowFailure(placementId: String?, error: UnityAds.UnityAdsShowError?, message: String?) {
                        act.runOnUiThread { onFail() }
                    }

                    override fun onUnityAdsShowStart(placementId: String?) {}
                    override fun onUnityAdsShowClick(placementId: String?) {}
                    override fun onUnityAdsShowComplete(placementId: String?, state: UnityAds.UnityAdsShowCompletionState?) {
                        if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                            act.runOnUiThread { onReward() }
                        }
                    }
                })
            }

            override fun onUnityAdsFailedToLoad(placementId: String?, error: UnityAds.UnityAdsLoadError?, message: String?) {
                act.runOnUiThread { onFail() }
            }
        })
    }
}

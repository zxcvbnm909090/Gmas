package com.gamedeals.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.util.Locale

/** Runs hourly in the background: new free games, big discounts, ending offers, price drops. */
class CheckWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {

    override suspend fun doWork(): Result {
        val c = applicationContext
        Store.init(c)
        Api.init(c)
        Notifier.channels(c)
        return try {
            checkFree(c)
            checkDeals(c)
            checkFavorites(c)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private suspend fun checkFree(c: Context) {
        val list = Api.free(null, true)
        val seen = Store.seen("seen_free")
        val first = !Store.sp.getBoolean("init_free", false)
        if (!first) {
            list.filter { it.id !in seen }.take(5).forEach {
                Notifier.notify(c, Notifier.CH_FREE, it.id.hashCode(), c.getString(R.string.n_free_title), it.title, it.url)
            }
        }
        Store.setSeen("seen_free", list.map { it.id })
        Store.sp.edit().putBoolean("init_free", true).apply()
    }

    private suspend fun checkDeals(c: Context) {
        val big = Api.deals(null, true).filter { it.discountPct >= 75 && (it.rating ?: 0) >= 70 }
        val seen = Store.seen("seen_deals")
        val first = !Store.sp.getBoolean("init_deals", false)
        if (!first) {
            big.filter { it.id !in seen }.take(3).forEach {
                val price = String.format(Locale.US, "\$%.2f", it.currentPrice ?: 0.0)
                Notifier.notify(
                    c, Notifier.CH_DEALS, it.id.hashCode(), c.getString(R.string.n_deal_title),
                    "${it.title}: -${it.discountPct}% → $price (${it.storeName})", it.url
                )
            }
        }
        Store.setSeen("seen_deals", big.map { it.id })
        Store.sp.edit().putBoolean("init_deals", true).apply()
    }

    private suspend fun checkFavorites(c: Context) {
        val now = System.currentTimeMillis()
        val favs = Store.favorites().toMutableList()
        val seenEnd = Store.seen("seen_end").toMutableSet()
        var changed = false
        for (i in favs.indices) {
            val f = favs[i]
            try {
                if (f.kind == Kind.FREE) {
                    val e = f.endDate
                    if (e != null && e > now && e - now < 24 * 3600_000L && f.id !in seenEnd) {
                        Notifier.notify(c, Notifier.CH_END, f.id.hashCode(), c.getString(R.string.n_end_title), f.title, f.url)
                        seenEnd.add(f.id)
                    }
                } else {
                    val old = f.currentPrice
                    val cur = Api.cheapest(f.title)
                    if (old != null && cur != null && cur.first < old - 0.009) {
                        val price = String.format(Locale.US, "\$%.2f", cur.first)
                        Notifier.notify(
                            c, Notifier.CH_END, f.id.hashCode() + 1, c.getString(R.string.n_drop_title),
                            "${f.title}: $price", cur.second
                        )
                        favs[i] = f.copy(currentPrice = cur.first)
                        changed = true
                    }
                }
            } catch (e: Exception) {
            }
        }
        Store.setSeen("seen_end", seenEnd)
        if (changed) Store.saveFavorites(favs)
    }
}

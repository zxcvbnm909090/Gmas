package com.gamedeals.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val cBg = Color(0xFF0E0B1A)
val cSurface = Color(0xFF181330)
val cCard = Color(0xFF241D45)
val cPurple = Color(0xFF8B5CF6)
val cBlue = Color(0xFF3B82F6)
val cGreen = Color(0xFF22C55E)
val cPink = Color(0xFFF43F5E)
val cText = Color(0xFFEDE9FE)
val cMuted = Color(0xFFB8B0D9)

@Composable
fun GameDealsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = cPurple,
            onPrimary = Color.White,
            secondary = cBlue,
            tertiary = cGreen,
            background = cBg,
            onBackground = cText,
            surface = cSurface,
            onSurface = cText,
            surfaceVariant = cCard,
            onSurfaceVariant = cMuted,
            surfaceContainer = cSurface,
            surfaceContainerHigh = cCard,
            surfaceContainerHighest = cCard,
            secondaryContainer = Color(0xFF3B2A7A),
            onSecondaryContainer = Color.White
        ),
        content = content
    )
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.gamedeals.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.text.DateFormat
import java.util.Date
import java.util.Locale

fun money(v: Double): String = String.format(Locale.US, "\$%.2f", v)

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(Config.link(url))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
    }
}

@Composable
fun endText(end: Long?): String? {
    if (end == null) return null
    val ctx = LocalContext.current
    val left = end - System.currentTimeMillis()
    return when {
        left <= 0 -> ctx.getString(R.string.ended)
        left < 24 * 3600_000L -> ctx.getString(R.string.ends_h, (left / 3600_000L).toInt().coerceAtLeast(1))
        else -> ctx.getString(R.string.ends_d, (left / 86_400_000L).toInt())
    }
}

// ---------------------------------------------------------------- lists

@Composable
fun PlatformChips(list: List<Plat>, sel: Plat, onSel: (Plat) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(list) { p ->
            FilterChip(selected = p == sel, onClick = { onSel(p) }, label = { Text(stringResource(p.label)) })
        }
    }
}

@Composable
fun GameList(
    state: UiState,
    list: List<Game>,
    favIds: Set<String>,
    emptyText: String,
    onFav: (Game) -> Unit,
    onOpen: (Game) -> Unit,
    onRetry: () -> Unit
) {
    when {
        state.loading && list.isEmpty() ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }

        state.error != null && list.isEmpty() ->
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(stringResource(R.string.err), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onRetry) { Text(stringResource(R.string.retry)) }
            }

        list.isEmpty() ->
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(emptyText, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

        else ->
            LazyVerticalGrid(
                columns = GridCells.Adaptive(320.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list, key = { it.id }) { g ->
                    GameCard(g, g.id in favIds, onFav = { onFav(g) }, onClick = { onOpen(g) })
                }
            }
    }
}

@Composable
fun GameCard(g: Game, fav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cCard)
    ) {
        Box {
            AsyncImage(
                model = g.image,
                contentDescription = g.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(460f / 215f).background(cSurface)
            )
            PriceBadge(g, Modifier.align(Alignment.TopStart).padding(8.dp))
            IconButton(
                onClick = onFav,
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).background(Color(0x99000000), CircleShape)
            ) {
                Icon(
                    if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = null,
                    tint = if (fav) cPink else Color.White
                )
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(
                g.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(4.dp))
            Text(g.storeName, style = MaterialTheme.typography.bodySmall, color = cMuted)
            endText(g.endDate)?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = cBlue)
            }
            Spacer(Modifier.height(8.dp))
            PriceRow(g)
        }
    }
}

@Composable
fun PriceBadge(g: Game, modifier: Modifier = Modifier) {
    val text = if (g.kind == Kind.FREE) stringResource(R.string.free) else stringResource(R.string.off, g.discountPct)
    Text(
        text,
        modifier = modifier.background(if (g.kind == Kind.FREE) cGreen else cPurple, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp
    )
}

@Composable
fun PriceRow(g: Game, big: Boolean = false) {
    val op = g.originalPrice
    val cp = g.currentPrice
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (op != null && op > 0) {
            Text(money(op), textDecoration = TextDecoration.LineThrough, color = cMuted)
        }
        Text(
            if (g.kind == Kind.FREE || cp == null || cp == 0.0) stringResource(R.string.free) else money(cp),
            color = cGreen, fontWeight = FontWeight.Bold,
            style = if (big) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium
        )
        g.rating?.let {
            Spacer(Modifier.weight(1f))
            Text("★ $it%", color = Color(0xFFFBBF24), fontWeight = FontWeight.SemiBold)
        }
    }
}

// ---------------------------------------------------------------- tabs

@Composable
fun FreeScreen(vm: MainVM) {
    val favIds = vm.favs.map { it.id }.toSet()
    val q = vm.query.trim()
    val base = if (vm.limitedOnly) vm.free.items.filter { it.endDate != null } else vm.free.items
    val list = if (q.isEmpty()) base else base.filter { it.title.contains(q, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        PlatformChips(Plat.entries, vm.freePlatform) { vm.selectFreePlatform(it) }
        Row(Modifier.padding(horizontal = 12.dp)) {
            FilterChip(
                selected = vm.limitedOnly,
                onClick = { vm.limitedOnly = !vm.limitedOnly },
                label = { Text(stringResource(R.string.limited_only)) }
            )
        }
        PullToRefreshBox(
            isRefreshing = vm.free.loading && vm.free.items.isNotEmpty(),
            onRefresh = { vm.loadFree(true) },
            modifier = Modifier.fillMaxSize()
        ) {
            GameList(vm.free, list, favIds, stringResource(if (q.isEmpty()) R.string.empty_free else R.string.empty_search), vm::toggleFav, { vm.selected = it }, { vm.loadFree(true) })
        }
    }
}

@Composable
fun DealsScreen(vm: MainVM) {
    val favIds = vm.favs.map { it.id }.toSet()
    Column(Modifier.fillMaxSize()) {
        PlatformChips(listOf(Plat.PC, Plat.STEAM, Plat.EPIC), vm.dealPlatform) { vm.selectDealPlatform(it) }
        Text(
            stringResource(R.string.deals_note),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall, color = cMuted
        )
        PullToRefreshBox(
            isRefreshing = vm.deals.loading && vm.deals.items.isNotEmpty(),
            onRefresh = { vm.loadDeals(true) },
            modifier = Modifier.fillMaxSize()
        ) {
            GameList(vm.deals, vm.deals.items, favIds, stringResource(if (vm.query.isBlank()) R.string.empty_deals else R.string.empty_search), vm::toggleFav, { vm.selected = it }, { vm.loadDeals(true) })
        }
    }
}

@Composable
fun FavScreen(vm: MainVM) {
    val favIds = vm.favs.map { it.id }.toSet()
    val q = vm.query.trim()
    val list = if (q.isEmpty()) vm.favs else vm.favs.filter { it.title.contains(q, ignoreCase = true) }
    GameList(UiState(), list, favIds, stringResource(if (q.isEmpty()) R.string.empty_fav else R.string.empty_search), vm::toggleFav, { vm.selected = it }, {})
}

@Composable
fun SettingsScreen(vm: MainVM) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.notif_title), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.notif_desc), color = cMuted, style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = vm.notif, onCheckedChange = { vm.setNotif(ctx, it) })
        }
        OutlinedButton(onClick = {
            val act = ctx as? Activity
            if (act != null) {
                Ads.showRewardedAdMob(
                    act,
                    onReward = {
                        vm.grantAdFree()
                        Toast.makeText(act, act.getString(R.string.ads_hidden), Toast.LENGTH_SHORT).show()
                    },
                    onFail = { Toast.makeText(act, act.getString(R.string.ad_fail), Toast.LENGTH_SHORT).show() }
                )
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.watch_ad_admob), textAlign = TextAlign.Center)
        }
        OutlinedButton(onClick = {
            val act = ctx as? Activity
            if (act != null) {
                Ads.showRewardedUnity(
                    act,
                    onReward = {
                        vm.grantAdFree()
                        Toast.makeText(act, act.getString(R.string.ads_hidden), Toast.LENGTH_SHORT).show()
                    },
                    onFail = { Toast.makeText(act, act.getString(R.string.ad_fail), Toast.LENGTH_SHORT).show() }
                )
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.watch_ad_unity), textAlign = TextAlign.Center)
        }
        Text(stringResource(R.string.sources), color = cMuted, style = MaterialTheme.typography.bodySmall)
        Text(stringResource(R.string.disclaimer), color = cMuted, style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------------------------------------------------------- detail

@Composable
fun DetailScreen(vm: MainVM, g: Game) {
    val ctx = LocalContext.current
    var rawg by remember(g.id) { mutableStateOf<Rawg?>(null) }
    LaunchedEffect(g.id) { rawg = Api.rawg(g.title) }
    val fav = vm.favs.any { it.id == g.id }
    val desc = g.description.ifEmpty { rawg?.description ?: "" }
    val image = g.image.ifEmpty { rawg?.image ?: "" }

    Scaffold(
        containerColor = cBg,
        topBar = {
            TopAppBar(
                title = { Text(g.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { vm.selected = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.cd_back))
                    }
                },
                actions = {
                    IconButton(onClick = { vm.toggleFav(g) }) {
                        Icon(
                            if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = null, tint = if (fav) cPink else cText
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = cBg, titleContentColor = cText,
                    navigationIconContentColor = cText, actionIconContentColor = cText
                )
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            Box {
                AsyncImage(
                    model = image, contentDescription = g.title, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(cSurface)
                )
                PriceBadge(g, Modifier.align(Alignment.TopStart).padding(12.dp))
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(g.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
                PriceRow(g, big = true)
                if (g.storeName.isNotEmpty()) Text(stringResource(R.string.store_label, g.storeName), color = cMuted)
                if (g.platforms.isNotEmpty()) Text(stringResource(R.string.platforms_label, g.platforms), color = cMuted)
                g.rating?.let { Text(stringResource(R.string.rating_label, it), color = cMuted) }
                rawg?.rating?.let { Text(stringResource(R.string.rawg_rating, it), color = cMuted) }
                g.endDate?.let {
                    Text(
                        stringResource(R.string.end_date, DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(it))),
                        color = cBlue
                    )
                    endText(it)?.let { t -> Text(t, color = cBlue, fontWeight = FontWeight.SemiBold) }
                }
                Button(
                    onClick = { openUrl(ctx, g.url) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        stringResource(if (g.kind == Kind.FREE) R.string.get_game else R.string.open_store),
                        fontWeight = FontWeight.Bold
                    )
                }
                if (desc.isNotEmpty()) {
                    Text(stringResource(R.string.about_game), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(desc, color = cText)
                }
            }
        }
    }
}

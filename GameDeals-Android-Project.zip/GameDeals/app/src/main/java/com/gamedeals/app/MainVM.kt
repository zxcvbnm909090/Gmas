package com.gamedeals.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

enum class Plat(val label: Int, val gp: String?, val storeId: String?) {
    ALL(R.string.p_all, null, null),
    PC(R.string.p_pc, "pc", null),
    STEAM(R.string.p_steam, "steam", "1"),
    EPIC(R.string.p_epic, "epic-games-store", "25"),
    PLAYSTATION(R.string.p_ps, "ps4.ps5", null),
    XBOX(R.string.p_xbox, "xbox-one.xbox-series-xs.xbox-360", null),
    ANDROID(R.string.p_android, "android", null),
    IOS(R.string.p_ios, "ios", null)
}

class MainVM : ViewModel() {
    var free by mutableStateOf(UiState())
        private set
    var deals by mutableStateOf(UiState())
        private set
    var favs by mutableStateOf(Store.favorites())
        private set
    var freePlatform by mutableStateOf(Plat.ALL)
        private set
    var dealPlatform by mutableStateOf(Plat.PC)
        private set
    var limitedOnly by mutableStateOf(false)
    var selected by mutableStateOf<Game?>(null)
    var notif by mutableStateOf(Store.notifOn)
        private set
    var adsFreeUntil by mutableStateOf(Store.adsFreeUntil)
        private set

    private var freeJob: Job? = null
    private var dealsJob: Job? = null

    fun setFreePlatform(p: Plat) {
        freePlatform = p
        free = UiState(loading = true)
        loadFree()
    }

    fun setDealPlatform(p: Plat) {
        dealPlatform = p
        deals = UiState(loading = true)
        loadDeals()
    }

    fun loadFree(force: Boolean = false) {
        freeJob?.cancel()
        freeJob = viewModelScope.launch {
            free = free.copy(loading = true, error = null)
            free = try {
                UiState(items = Api.free(freePlatform.gp, force).distinctBy { it.id })
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiState(error = e.message ?: "error", items = free.items)
            }
        }
    }

    fun loadDeals(force: Boolean = false) {
        dealsJob?.cancel()
        dealsJob = viewModelScope.launch {
            deals = deals.copy(loading = true, error = null)
            deals = try {
                UiState(items = Api.deals(dealPlatform.storeId, force).distinctBy { it.id })
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiState(error = e.message ?: "error", items = deals.items)
            }
        }
    }

    fun toggleFav(g: Game) {
        val cur = favs
        favs = if (cur.any { it.id == g.id }) cur.filterNot { it.id == g.id } else cur + g
        Store.saveFavorites(favs)
    }

    fun setNotif(ctx: Context, on: Boolean) {
        notif = on
        Store.notifOn = on
        if (on) App.schedule(ctx) else App.cancel(ctx)
    }

    fun grantAdFree() {
        val t = System.currentTimeMillis() + 24 * 3600_000L
        Store.adsFreeUntil = t
        adsFreeUntil = t
    }
}

package com.gamedeals.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.delay

enum class Screen(val label: Int, val icon: ImageVector) {
    FREE(R.string.tab_free, Icons.Default.Star),
    DEALS(R.string.tab_deals, Icons.Default.ShoppingCart),
    FAV(R.string.tab_fav, Icons.Default.Favorite),
    SETTINGS(R.string.tab_settings, Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        MobileAds.initialize(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        setContent { GameDealsTheme { AppRoot() } }
    }
}

@Composable
fun BannerAd() {
    AndroidView(
        modifier = Modifier.fillMaxWidth(),
        factory = { ctx ->
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = Config.BANNER_ID
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: MainVM = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(Screen.FREE) }

    // Initial load + automatic refresh every 10 minutes while the app is open.
    LaunchedEffect(Unit) {
        vm.loadFree()
        vm.loadDeals()
        while (true) {
            delay(10 * 60_000L)
            vm.loadFree(true)
            vm.loadDeals(true)
        }
    }

    val sel = vm.selected
    if (sel != null) {
        BackHandler { vm.selected = null }
        DetailScreen(vm, sel)
        return
    }

    val showAds = System.currentTimeMillis() > vm.adsFreeUntil

    Scaffold(
        containerColor = cBg,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    IconButton(onClick = { vm.loadFree(true); vm.loadDeals(true) }) {
                        Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.cd_refresh))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = cBg, titleContentColor = cText, actionIconContentColor = cText
                )
            )
        },
        bottomBar = {
            Column {
                if (showAds) BannerAd()
                NavigationBar(containerColor = cSurface) {
                    Screen.entries.forEach { s ->
                        NavigationBarItem(
                            selected = tab == s,
                            onClick = { tab = s },
                            icon = { Icon(s.icon, contentDescription = null) },
                            label = { Text(stringResource(s.label)) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                Screen.FREE -> FreeScreen(vm)
                Screen.DEALS -> DealsScreen(vm)
                Screen.FAV -> FavScreen(vm)
                Screen.SETTINGS -> SettingsScreen(vm)
            }
        }
    }
}

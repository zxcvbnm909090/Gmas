package com.gamedeals.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/** Local persistence: favorites, notification state, ad-free timer. */
object Store {
    lateinit var sp: SharedPreferences

    fun init(c: Context) {
        sp = c.getSharedPreferences("gamedeals", Context.MODE_PRIVATE)
    }

    fun favorites(): List<Game> = try {
        val a = JSONArray(sp.getString("fav", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).toGame() }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveFavorites(l: List<Game>) {
        sp.edit().putString("fav", JSONArray(l.map { it.toJson() }).toString()).apply()
    }

    fun seen(key: String): Set<String> = sp.getStringSet(key, emptySet())!!.toSet()
    fun setSeen(key: String, ids: Collection<String>) {
        sp.edit().putStringSet(key, ids.toSet()).apply()
    }

    var notifOn: Boolean
        get() = sp.getBoolean("notif", true)
        set(v) { sp.edit().putBoolean("notif", v).apply() }

    var adsFreeUntil: Long
        get() = sp.getLong("ads_free_until", 0L)
        set(v) { sp.edit().putLong("ads_free_until", v).apply() }
}

object Config {
    // Google AdMob TEST ids. Replace with your real ad unit ids before publishing.
    const val BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    // Affiliate tracking: put your query string here (e.g. "ref=myid"); it is appended to store links.
    const val AFFILIATE_QUERY = ""

    fun link(url: String): String =
        if (AFFILIATE_QUERY.isBlank()) url
        else url + (if (url.contains("?")) "&" else "?") + AFFILIATE_QUERY
}
